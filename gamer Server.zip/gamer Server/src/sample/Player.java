package sample;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.ArrayList;

public class Player {
    private ArrayList<String> cardsHaves;
    private DataOutputStream out ;
    private DataOutputStream in ;





















}
